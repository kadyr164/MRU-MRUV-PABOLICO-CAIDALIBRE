package com.example.mrumruvcaidalireparab;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PARABOLICOjava extends AppCompatActivity {

    private EditText etV0, etTheta, etG;
    private TextView tvRango, tvAltura, tvTiempo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.parabolico);

        etV0     = findViewById(R.id.et_v0_parab);
        etTheta  = findViewById(R.id.et_theta);
        etG      = findViewById(R.id.et_g_parab);
        tvRango  = findViewById(R.id.tv_rango);
        tvAltura = findViewById(R.id.tv_altura);
        tvTiempo = findViewById(R.id.tv_tiempo);

        findViewById(R.id.btn_parab_calcular).setOnClickListener(v -> calcularParabolico());
    }

    private void calcularParabolico() {
        String v0Str = etV0.getText().toString().trim();
        String thStr = etTheta.getText().toString().trim();
        String gStr  = etG.getText().toString().trim();

        if (TextUtils.isEmpty(v0Str) || TextUtils.isEmpty(thStr)) {
            tvRango.setText("Ingresa v₀ y θ");
            tvAltura.setText(""); tvTiempo.setText("");
            return;
        }
        if (TextUtils.isEmpty(gStr)) gStr = "9.81";

        double v0 = Double.parseDouble(v0Str);
        double thetaDeg = Double.parseDouble(thStr);
        double g  = Double.parseDouble(gStr);

        double thetaRad = Math.toRadians(thetaDeg);

        double R = v0 * v0 * Math.sin(2 * thetaRad) / g;
        double H = v0 * v0 * Math.pow(Math.sin(thetaRad), 2) / (2 * g);
        double T = 2 * v0 * Math.sin(thetaRad) / g;

        tvRango.setText(String.format("R: %.2f m", R));
        tvAltura.setText(String.format("H: %.2f m", H));
        tvTiempo.setText(String.format("T: %.2f s", T));
    }
}
