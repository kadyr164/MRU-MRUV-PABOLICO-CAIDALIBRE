package com.example.mrumruvcaidalireparab;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void irAMRU(View v) {
        startActivity(new Intent(this, MRUjava.class));
    }

    public void irAMRUV(View v) {
        startActivity(new Intent(this, MRUVjava.class));
    }

    public void irACaidaLibre(View v) {
        startActivity(new Intent(this, CAIDALIBREjava.class));
    }

    public void irAParabolico(View v) {
        startActivity(new Intent(this, PARABOLICOjava.class));
    }
}
