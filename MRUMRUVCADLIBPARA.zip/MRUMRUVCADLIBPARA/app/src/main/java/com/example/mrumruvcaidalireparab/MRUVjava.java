package com.example.mrumruvcaidalireparab;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MRUVjava extends AppCompatActivity {

    private EditText etV0, etA, etT;
    private TextView tvVf, tvS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mruv);   // usa el XML anterior

        etV0 = findViewById(R.id.et_v0);
        etA  = findViewById(R.id.et_a);
        etT  = findViewById(R.id.et_t);
        tvVf = findViewById(R.id.tv_vf);
        tvS  = findViewById(R.id.tv_s);

        findViewById(R.id.btn_mruv_calcular).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                calcularMRUV();
            }
        });
    }

    private void calcularMRUV() {
        String v0Str = etV0.getText().toString().trim();
        String aStr  = etA.getText().toString().trim();
        String tStr  = etT.getText().toString().trim();

        if (TextUtils.isEmpty(v0Str) || TextUtils.isEmpty(aStr) || TextUtils.isEmpty(tStr)) {
            tvVf.setText("Completa v₀, a y t");
            tvS.setText("");
            return;
        }

        double v0 = Double.parseDouble(v0Str);
        double a  = Double.parseDouble(aStr);
        double t  = Double.parseDouble(tStr);

        double vf = v0 + a * t;
        double s  = v0 * t + 0.5 * a * t * t;

        tvVf.setText(String.format("v final: %.2f m/s", vf));
        tvS.setText(String.format("desplazamiento: %.2f m", s));
    }
}
