package com.example.mrumruvcaidalireparab;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MRUjava extends AppCompatActivity {

    // IDs que existen en tu XML
    private EditText etDistancia;   // editTextNumber
    private EditText etTiempo;      // editTextNumber4
    private TextView tvResultado;   // resultado

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mru);   // el XML que pegaste


        etDistancia = findViewById(R.id.editTextNumber);
        etTiempo    = findViewById(R.id.editTextNumber4);
        tvResultado = findViewById(R.id.resultado);


        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                calcularVelocidad();
            }
        });
    }

    private void calcularVelocidad() {
        String dStr = etDistancia.getText().toString().trim();
        String tStr = etTiempo.getText().toString().trim();

        // Validaciones simples
        if (TextUtils.isEmpty(dStr) || TextUtils.isEmpty(tStr)) {
            tvResultado.setText("Completa distancia y tiempo");
            return;
        }

        double distancia = Double.parseDouble(dStr);
        double tiempo    = Double.parseDouble(tStr);

        if (tiempo == 0) {
            tvResultado.setText("Tiempo no puede ser 0");
            return;
        }

        double velocidad = distancia / tiempo;
        tvResultado.setText(String.format("Velocidad: %.2f m/s", velocidad));
    }
}
