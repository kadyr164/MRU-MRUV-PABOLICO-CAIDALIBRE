package com.example.mrumruvcaidalireparab;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CAIDALIBREjava extends AppCompatActivity {

    private EditText etT, etG;
    private TextView tvV, tvH;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.caidalibre);

        etT = findViewById(R.id.et_t_cl);
        etG = findViewById(R.id.et_g_cl);
        tvV = findViewById(R.id.tv_v_cl);
        tvH = findViewById(R.id.tv_h_cl);

        findViewById(R.id.btn_cl_calcular).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                calcularCaidaLibre();
            }
        });
    }

    /** Calcula velocidad final y altura recorrida en caída libre (v0 = 0) */
    private void calcularCaidaLibre() {
        String tStr = etT.getText().toString().trim();
        String gStr = etG.getText().toString().trim();

        if (TextUtils.isEmpty(tStr)) {
            tvV.setText("Ingresa t");
            tvH.setText("");
            return;
        }
        if (TextUtils.isEmpty(gStr)) gStr = "9.81";  // valor por defecto

        double t = Double.parseDouble(tStr);
        double g = Double.parseDouble(gStr);

        double v = g * t;
        double h = 0.5 * g * t * t;

        tvV.setText(String.format("v: %.2f m/s", v));
        tvH.setText(String.format("h: %.2f m", h));
    }
}
